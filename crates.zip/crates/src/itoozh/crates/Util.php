<?php

namespace itoozh\crates;

use pocketmine\Server;
use pocketmine\world\Position;
use pocketmine\world\WorldException;
use pocketmine\world\WorldManager;
use InvalidArgumentException;
use pocketmine\data\SavedDataLoadingException;
use pocketmine\item\Item;
use pocketmine\nbt\BigEndianNbtSerializer;
use pocketmine\nbt\NBT;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\nbt\TreeRoot;
use function count;

final class Util {
    private static ?WorldManager $WORLD_MANAGER = null;
    private const TAG_NAME = "contents";

    private function __construct() {
    }

    public static function fromString(string $data): Position {
        $dat = explode(":", $data);
        if(count($dat) !== 4) {
            throw new \UnexpectedValueException("Expected string with format x:y:z:world. $data given");
        }
        $wName = $dat[3];
        if(self::$WORLD_MANAGER === null) {
            self::$WORLD_MANAGER = Server::getInstance()->getWorldManager();
        }
        if(!self::$WORLD_MANAGER->isWorldLoaded($wName) && !self::$WORLD_MANAGER->loadWorld($wName)) {
            throw new WorldException("Unable to find world: '$wName'");
        }
        return new Position((float)$dat[0], (float)$dat[1], (float)$dat[2], self::$WORLD_MANAGER->getWorldByName($dat[3]));
    }

    public static function toString(Position $pos): string {
        return "$pos->x:$pos->y:$pos->z:{$pos->world->getFolderName()}";
    }

    /**
     * @param array<int, Item> $contents
     * @return string
     */
    public static function serialize(array $contents) : string{
        if(count($contents) === 0){
            return "";
        }

        $contents_tag = [];
        foreach($contents as $slot => $item){
            $contents_tag[] = $item->nbtSerialize($slot);
        }
        return (new BigEndianNbtSerializer())->write(new TreeRoot(CompoundTag::create()->setTag(self::TAG_NAME, new ListTag($contents_tag, NBT::TAG_Compound))));
    }

    /**
     * @param string $string
     * @return array<int, Item>
     */
    public static function deSerialize(string $string) : array{
        if($string === ""){
            return [];
        }

        $tag = (new BigEndianNbtSerializer())->read($string)->mustGetCompoundTag()->getListTag(self::TAG_NAME) ?? throw new InvalidArgumentException("Invalid serialized string specified");

        $contents = [];
        /** @var CompoundTag $value */
        foreach($tag as $value){
            try{
                $item = Item::nbtDeserialize($value);
            }catch(SavedDataLoadingException){
                continue;
            }
            $contents[$value->getByte("Slot")] = $item;
        }
        return $contents;
    }
}