<?php

declare(strict_types=1);

namespace itoozh\crates\lib\muqsit\invmenu\type\util\builder;

use itoozh\crates\lib\muqsit\invmenu\type\InvMenuType;

interface InvMenuTypeBuilder{

	public function build() : InvMenuType;
}