<?php

namespace itoozh\crates;

use itoozh\crates\command\CrateItemCommand;
use itoozh\crates\command\CrateCommand;
use itoozh\crates\command\KeyCommand;
use itoozh\crates\crate\Crate;
use itoozh\crates\crate\FloatingText;
use itoozh\crates\effect\CrateEffect;
use itoozh\crates\entity\Hologram;
use itoozh\crates\lib\FloatingTextApi;
use itoozh\crates\lib\muqsit\invmenu\InvMenuHandler;
use pocketmine\entity\EntityDataHelper;
use pocketmine\entity\EntityFactory;
use pocketmine\entity\Location;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\scheduler\ClosureTask;
use pocketmine\Server;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat;
use pocketmine\world\Position;
use pocketmine\world\World;

class Main extends PluginBase
{
    private static Config $cratesData;
    private static Config $cratesPlacedData;
    /** @var array<string, Crate> */
    private static array $crates = [];
    /** @var array<string, Crate> */
    private static array $placedCrates = [];
    /** @var array<string, Crate> */
    private static array $playersPlacing = [];
    /** @var array<string, bool> */
    private static array $removingCrate = [];
    protected function onEnable(): void
    {
        if(!InvMenuHandler::isRegistered()) InvMenuHandler::register($this);

        $this->saveResource("crates.json");
        $this->saveResource("cratesPlaced.json");

        self::$cratesData = new Config($this->getDataFolder() . "crates.json", Config::JSON);
        self::$cratesPlacedData = new Config($this->getDataFolder() . "cratesPlaced.json", Config::JSON);
        
        EntityFactory::getInstance()->register(Hologram::class, function (World $world, CompoundTag $nbt) : Hologram {
            return new Hologram(EntityDataHelper::parseLocation($nbt, $world), $nbt);
        }, ['Hologram']);

        self::load();

        $this->getServer()->getCommandMap()->register("CRATES", new CrateCommand());
        $this->getServer()->getCommandMap()->register("CRATES", new CrateItemCommand());
        $this->getServer()->getCommandMap()->register("CRATES", new KeyCommand());

        $this->getServer()->getPluginManager()->registerEvents(new EventHandler(), $this);

        /*$this->getScheduler()->scheduleRepeatingTask(new ClosureTask(function ():void {
            self::tick();
        }), 20);*/
    }

    protected function onDisable(): void
    {
        self::save();
    }

    public static function save(): void
    {
        self::$cratesData->setAll([]);
        self::$cratesPlacedData->setAll([]);

        foreach (self::$crates as $name => $crate) {
            self::$cratesData->set($name, $crate->jsonSerialize());
            self::$cratesData->save();
        }
        foreach (self::$placedCrates as $pos => $crate) {
            self::$cratesPlacedData->set($pos, ["crate" => $crate->getName()]);
            self::$cratesPlacedData->save();
        }
    }

    /**
     * Obtiene las CRATES colocadas en un radio alrededor de una posición dada.
     *
     * @param Position $centerPosition La posición central alrededor de la cual buscar CRATES.
     * @param float $radius El radio dentro del cual buscar CRATES.
     * @return array|null Un array de CRATES que se encuentran dentro del radio especificado o null si no se encontraron CRATES.
     */
    public static function getCratesInRadius(Position $centerPosition, float $radius = 5): ?array {
        $cratesInRadius = [];

        foreach (self::$placedCrates as $position => $crate) {
            $cratePosition = Util::fromString($position);
            $distance = $centerPosition->distance($cratePosition);

            if ($distance <= $radius) {
                $cratesInRadius[$position] = $crate;
            }
        }

        return empty($cratesInRadius) ? null : $cratesInRadius;
    }


    public static function load(): void
    {
        foreach (self::$cratesData->getAll() as $name => $data) {
            $crate = new Crate($name, $data["color"], $data["menu"]);
            $crate->setPlace($data["place"]);
            $crate->setHologram($data["hologram"]);
            $crate->setEffect($data["effect"]);
            $crate->setDecorative(Util::deSerialize(base64_decode($data["itemsDecorative"])));
            $crate->setRewards(Util::deSerialize(base64_decode($data["rewards"])));
            $crate->setRewardAmount($data["rewardAmount"]);
            $crate->setItemKey(Util::deSerialize(base64_decode($data["itemKey"]))[0]);
            self::createCrate($crate);
        }

        foreach (self::$cratesPlacedData->getAll() as $pos => $data) {
            $crate = self::getCrate($data["crate"]);
            if ($crate == null) {
                continue;
            }
            self::placeCrateOne(Util::fromString($pos), self::getCrate($data["crate"]));
        }
    }

    public static function getCrate(string $name): ?Crate
    {
        return self::$crates[$name] ?? null;
    }

    public static function createCrate(Crate $crate): void
    {
        self::$crates[$crate->getName()] = $crate;
    }

    public static function addToPlace(Player $player, Crate $crate) : void
    {
        self::$playersPlacing[$player->getName()] = $crate;
        $player->sendMessage(TextFormat::GREEN . "Interact with a block to place " . $crate->getDisplayName() . TextFormat::GREEN . " crate.");
    }

    public static function removeFromPlace(Player $player) : void
    {
        unset(self::$playersPlacing[$player->getName()]);
        $player->sendMessage(TextFormat::GREEN . "Crate place process has been ended.");
    }

    public static function getCratePlacing(Player $player) : ?Crate
    {
        return self::$playersPlacing[$player->getName()] ?? null;
    }

    public static function checkCrate(Position $position) : ?Crate
    {
        return self::$placedCrates[Util::toString($position)] ?? null;
    }


    public static function getPlacedCrates(): array
    {
        return self::$placedCrates;
    }

    private static array $holograms = [];
    
    public static function placeCrateOne(Position $position, Crate $crate) : void {
        self::$placedCrates[Util::toString($position)] = $crate;
    }
    
    public static function placeCrate(Position $position, Crate $crate) : void
    {
        self::$placedCrates[Util::toString($position)] = $crate;
        //self::updateHolograms();
        self::addHologram($crate->getName(), $position, $crate->getHologram());
        //self::$holograms[Util::toString($position)] = FloatingTextApi::createText($position);
    }

    public static function getHologram(Position $position) : ?FloatingTextApi
    {
        return self::$holograms[Util::toString($position)] ?? null;
    }

    public static function updateHolograms(): void {
        foreach (Server::getInstance()->getWorldManager()->getWorlds() as $world) {
            foreach ($world->getEntities() as $entity) {
                if ($entity instanceof Hologram) {
                    $entity->despawnFromAll();
                }
            }
        }
        foreach (self::$placedCrates as $position => $crate) {
            self::addHologram($crate->getName(), Util::fromString($position), $crate->getHologram());
        }
    }

    public static function addHologram(string $name, Position $position, array $lines): void {
        $newY = $position->y + 0.28;
        $LINES = array_reverse($lines);

        foreach ($LINES as $LINE) {
            $newY += 0.28;
            $hologram = new Hologram(new Location($position->x + 0.5, $newY, $position->z + 0.5, $position->world, 0, 0), null, $name, $LINE);
            $hologram->setCanSaveWithChunk(true);
            $hologram->spawnToAll();
        }
    }

    public static function tick(): void
    {
        foreach (self::$placedCrates as $position => $crate) {
            if ($crate->getEffect() == null) continue;
            $pos = Util::fromString($position);
            $newPos = new Position($pos->x + 0.5, $pos->y + 1, $pos->z + 0.5, $pos->world);
            CrateEffect::tick($crate->getEffect(), $newPos);
        }
    }

    public static function getCrates(): array {
        return self::$crates;
    }

    public static function deleteCrate(Crate $crate): void {
        foreach (self::$placedCrates as $pos => $cratePlaced) {
            if ($cratePlaced->getName() == $crate->getName()) {
                unset(self::$placedCrates[$pos]);
            }
        }
        unset(self::$crates[$crate->getName()]);
        self::updateHolograms();
    }

    public static function isRemovingCrate(Player $player): bool {
        return isset(self::$removingCrate[$player->getName()]);
    }

    public static function removeFromRemoving(Player $player): void {
        unset(self::$removingCrate[$player->getName()]);
        $player->sendMessage(TextFormat::GREEN . "Crate removing process has been ended.");
    }

    public static function setRemovingCrate(Player $player) : void {
        self::$removingCrate[$player->getName()] = true;
        $player->sendMessage(TextFormat::GREEN . "Interact with a crate to remove it.");
    }

    public static function removePlaceCrate(Position $position) : void {
        unset(self::$placedCrates[Util::toString($position)]);
        self::updateHolograms();
    }
}