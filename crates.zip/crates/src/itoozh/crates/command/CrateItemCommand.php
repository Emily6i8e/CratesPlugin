<?php

namespace itoozh\crates\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat;

class CrateItemCommand extends Command
{
    public function __construct()
    {
        parent::__construct("crateitem", "Use for manage the crates");
        $this->setPermission('use.crates.command');
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if (!$sender instanceof Player) return;

        if (!$this->testPermission($sender)) {
            return;
        }
        if (count($args) < 1) {
            $sender->sendMessage(TextFormat::colorize("&cUse /crateitem setname|setlore|setcommand|setdecorative"));
            return;
        }
        switch ($args[0]){
            case "setname":
                if (count($args) < 2) {$sender->sendMessage(TextFormat::colorize("&cUse /crateitem setname [string:customName]"));return;}
                if ($sender->getInventory()->getItemInHand()->getTypeId() === VanillaItems::AIR()->getTypeId()) { $sender->sendMessage(TextFormat::colorize("&l&4Crates &r&7| &cYou need a item in your hand!")); return;}
                $item = $sender->getInventory()->getItemInHand();
                unset($args[0]);
                $item->setCustomName(TextFormat::colorize("§r" . implode(" ", $args)));
                $sender->getInventory()->setItemInHand($item);
                $sender->sendMessage(TextFormat::colorize("&l&4Crates &r&7|&a Item edited custom name successfully!"));
                return;
            case "setlore":
                if (count($args) < 2) {$sender->sendMessage(TextFormat::colorize("&cUse /crateitem setlore [string:Lore]"));return;}
                if ($sender->getInventory()->getItemInHand()->getTypeId() === VanillaItems::AIR()->getTypeId()) { $sender->sendMessage(TextFormat::colorize("&l&4Crates &r&7| &cYou need a item in your hand!")); return;}
                $item = $sender->getInventory()->getItemInHand();
                unset($args[0]);
                $loreText = implode(" ", $args);
                $itemLore = explode("{n}", $loreText);

                $newItemLore = [];
                foreach ($itemLore as $lineLore){
                    $newItemLore[] = TextFormat::colorize("&r" . $lineLore);
                }

                $item->setLore($newItemLore);
                $sender->getInventory()->setItemInHand($item);
                $sender->sendMessage(TextFormat::colorize("&l&4Crates &r&7|&a Item edited lore successfully!"));
                return;
            case "setcommand":
                if (count($args) < 2) {$sender->sendMessage(TextFormat::colorize("&cUse /crateitem setcommand [string:customName]"));return;}
                if ($sender->getInventory()->getItemInHand()->getTypeId() === VanillaItems::AIR()->getTypeId()) { $sender->sendMessage(TextFormat::colorize("&l&4Crates &r&7| &cYou need a item in your hand!")); return;}
                $item = $sender->getInventory()->getItemInHand();
                unset($args[0]);
                if ($item->getNamedTag()->getTag("commands") !== null) {
                    $item->getNamedTag()->setString("commands", $item->getNamedTag()->getString("commands") . "{n}" . implode(" ", $args));
                } else {
                    $item->getNamedTag()->setString("type", "cmd");
                    $item->getNamedTag()->setString("commands", implode(" ", $args));
                }
                $sender->getInventory()->setItemInHand($item);
                $sender->sendMessage(TextFormat::colorize("&l&4Crates &r&7|&a Item added command successfully!"));
                return;
            case "setdecorative":
                if ($sender->getInventory()->getItemInHand()->getTypeId() === VanillaItems::AIR()->getTypeId()) { $sender->sendMessage(TextFormat::colorize("&l&4Crates &r&7| &cYou need a item in your hand!")); return;}
                $item = $sender->getInventory()->getItemInHand();
                $item->getNamedTag()->setString("type", "filler");
                $sender->getInventory()->setItemInHand($item);
                $sender->sendMessage(TextFormat::colorize("&l&4Crates &r&7|&a Item set decorative successfully!"));
                return;
        }
        $sender->sendMessage(TextFormat::colorize("&cUse /crateitem setname|setlore|setcommand|setdecorative"));
    }

}